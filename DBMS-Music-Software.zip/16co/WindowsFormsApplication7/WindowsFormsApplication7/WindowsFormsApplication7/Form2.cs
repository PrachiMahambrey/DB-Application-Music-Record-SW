﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication7
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form3 obj = new Form3();
            obj.Show();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form4 obj = new Form4();
            obj.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form5 obj = new Form5();
            obj.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form6 obj = new Form6();
            obj.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form7 obj = new Form7();
            obj.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form8 obj = new Form8();
            obj.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Form9 obj = new Form9();
            obj.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Form10 obj = new Form10();
            obj.Show();
        }


        private void button9_Click(object sender, EventArgs e)
        {
            join obj = new join();
            obj.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }




    }
}
