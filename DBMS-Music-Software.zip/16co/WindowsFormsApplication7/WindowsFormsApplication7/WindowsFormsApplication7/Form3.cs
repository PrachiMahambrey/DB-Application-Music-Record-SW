﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApplication7
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String connection = "Provider=OraOLEDB.Oracle;Data Source=localhost;User Id=SYSTEM;Password=system;OLEDB.NET=True";
            OleDbConnection obj1 = new OleDbConnection(connection);

            String q2 = "insert into musician(ssn,mname,age) values ('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "')";
            obj1.Open();

            try
            {
                OleDbCommand cm2 = new OleDbCommand(q2, obj1);
                cm2.ExecuteNonQuery();
                MessageBox.Show("Record Insert");

                String q1 = "select * from musician";
                OleDbDataAdapter da = new OleDbDataAdapter(q1, obj1);
                DataTable d = new DataTable();
                da.Fill(d);
                dataGridView1.DataSource = d;

                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();

                obj1.Close();
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            String connection = "Provider=OraOLEDB.Oracle;Data Source=localhost;User Id=SYSTEM;Password=system;OLEDB.NET=True";
            OleDbConnection obj1 = new OleDbConnection(connection);

            obj1.Open();
            String q2 = "delete from musician where SSN='" + textBox4.Text+"'";

         
            try{
                OleDbCommand cm2=new OleDbCommand(q2,obj1);
                cm2.ExecuteNonQuery();
                MessageBox.Show("Record Delete");

                textBox4.Clear();
              
                
                String q1 = "select * from musician";
               
                OleDbDataAdapter da = new OleDbDataAdapter(q1, obj1);
                DataTable d = new DataTable();
                da.Fill(d);
                dataGridView1.DataSource = d;
              
                                obj1.Close();

            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            String connection = "Provider=OraOLEDB.Oracle;Data Source=localhost;User Id=SYSTEM;Password=system;OLEDB.NET=True";
            
            OleDbConnection obj1 = new OleDbConnection(connection);


            obj1.Open();
            String q2 = "update musician set age='" + textBox5.Text+"' where ssn='"+textBox6.Text+"'";
            try
            {
                OleDbCommand cm2 = new OleDbCommand(q2, obj1);
                Int32 i = cm2.ExecuteNonQuery();
                if (i > 0)
                { MessageBox.Show("Record Updated"); }

                textBox5.Clear();
                textBox6.Clear();
              
                String q1 = "select * from musician";
               
                OleDbDataAdapter da = new OleDbDataAdapter(q1, obj1);
                DataTable d = new DataTable();
                da.Fill(d);
                dataGridView1.DataSource = d;
              
                obj1.Close();

            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form4 obj = new Form4();
            obj.Show();

        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            String connection = "Provider=OraOLEDB.Oracle;Data Source=localhost;User Id=SYSTEM;Password=system;OLEDB.NET=True";
            OleDbConnection obj1 = new OleDbConnection(connection);
            obj1.Open();
            String q1 = "select * from musician";

            OleDbDataAdapter da = new OleDbDataAdapter(q1, obj1);
            DataTable d = new DataTable();
            da.Fill(d);
            dataGridView1.DataSource = d;

            obj1.Close();
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            String connection = "Provider=OraOLEDB.Oracle;Data Source=localhost;User Id=SYSTEM;Password=system;OLEDB.NET=True";
            OleDbConnection obj1 = new OleDbConnection(connection);
            obj1.Open();
            String q1 = "select count(ssn) from musician";

            OleDbDataAdapter da = new OleDbDataAdapter(q1, obj1);
            DataTable d = new DataTable();
            da.Fill(d);
            dataGridView1.DataSource = d;

            obj1.Close();
        }

       
    }
}
