﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApplication7
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            String connection = "Provider=OraOLEDB.Oracle;Data Source=localhost;User Id=SYSTEM;Password=system;OLEDB.NET=True";
            OleDbConnection obj1 = new OleDbConnection(connection);
            obj1.Open();
            String q1 = "select * from p_phno";

            OleDbDataAdapter da = new OleDbDataAdapter(q1, obj1);
            DataTable d = new DataTable();
            da.Fill(d);
            dataGridView1.DataSource = d;

            obj1.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form8 obj = new Form8();
            obj.Show();

        }
    }
}
